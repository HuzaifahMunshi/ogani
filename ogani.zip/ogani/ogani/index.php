<?php
	session_start();
    error_reporting(0);
    $conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');
    if ($conn) {
        
    }
    // $product_searched = $_POST['search_product']; 
    $sql = "Select * from farmer_upload_products LIMIT 3 ";
    $res = $conn->query($sql);
    $row = $res->fetch_array(MYSQLI_ASSOC);
    $count = $res->num_rows;
        
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ogani | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
    <style>

.products {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.product-card{
    padding: 1%;
    margin-left: 10px;
}
.product-image img {
  max-width: 100%;

}
.product-info {
  margin-top: auto;
}
@media (max-width: 920px) {
  .product-card {
    flex: 1 21%;
  }
}
@media (max-width: 600px) {
  .product-card {
    flex: 1 46%;
  }
}

@media (max-width: 480px) {
  .product-filter {
    flex-direction: column;
  }
  .sort {
    align-self: flex-start;
  }
}
.container {
  position: relative;
  width: 100%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.3;
}

.container:hover .middle {
  opacity: 1;
}

.text {
  background-color: #7fad39;
  border-radius: 15px;
  color: white;
  font-size: 10px;
  padding: 16px 32px;
}

.db_image
{
    background-color: #f3f6fb;
    width: 270px;
    height: 270px;
    background-position: center;
}

.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #7fad39;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 10px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button:hover
{
color: rgba(255, 255, 255, 1);
  box-shadow: 0 10px 20px rgba(150, 92, 182, .5);
}

#update_input
{
    /*border: none;*/
    width: 50px;
    height: auto;
    align-content: center;
    text-align: center;
}
</style>

<body>

    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="img/logo.png" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                <li><a href="#"><i class="fa fa-shopping-bag"  style="font-size: 30px"></i> <span>3</span></a></li>
            </ul>
        </div>
        <div class="humberger__menu__widget">
           
            <div class="header__top__right__auth">
                <a href="javascript:login_check()">
                	<i class="fa fa-user"></i> <label id="login_id_mobile" style="cursor: pointer;">Login</label> 
                </a>
            </div>
	
	        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	        <div class="header__top__right__auth">
	        	<a href="javascript:sessionclose()">
	        		<label id="signout_id_mobile" style="cursor: pointer;"></label>
	        	</a>	
	        </div>

        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="php/shop-grid-test.php">Shop</a></li>
                <li><a href="#">Pages</a>
                    <ul class="header__menu__dropdown">
                        <li><a href="./shop-details.html">Shop Details</a></li>
                        <li><a href="php/shopping_cart.php">Shoping Cart</a></li>
                        <li><a href="php/checkout.php">Check Out</a></li>
                        
                    </ul>
                </li>
                
                <li><a href="./contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-pinterest-p"></i></a>
        </div>
        
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-6 col-md-6 ml-auto">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                           
                            <div class="header__top__right__auth">
                               <a href="javascript:login_check()"><i class="fa fa-user"></i> <label id="login_id_web" style="cursor: pointer;">Login</label></a>
                            </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <div class="header__top__right__auth">
                            	<a href="javascript:sessionclose()">
                            		<label id="signout_id_web" style="cursor: pointer;"></label>
                            	</a>	
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="./index.php"><img src="img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                        <ul>
                            <li class="active"><a href="index.php">Home</a></li>
                            <li><a href="php/shop-grid-test.php">Shop</a></li>
                            <li><a href="#">Pages</a>
                                <ul class="header__menu__dropdown">
                                    <li><a href="./shop-details.html">Shop Details</a></li>
                                    <li><a href="php/shopping_cart.php">Shoping Cart</a></li>
                                    <li><a href="php/checkout.php">Check Out</a></li>
                                    
                                </ul>
                            </li>
                            
                            <li><a href="./contact.html">Contact</a></li>
                        </ul>
                    </nav>
                </div>
               <div class="col-lg-2">
                    <div class="header__cart">
                        <ul>
                            <li><a href="#"><i class="fa fa-shopping-bag" style="font-size: 30px"></i> <span>3</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All departments</span>
                        </div>
                            
                        <ul>
                            <li><a href="javascript:veg_dept_click()" id="veg_dept">Vegetables</a></li>
                            <li><a href="javascript:fruit_dept_click()" id="fruit_dept">Fruits</a></li>
                            <li><a href="javascript:bne_dept_click()" id="bne_dept">Butter & Eggs</a></li>
                            <li><a href="javascript:spices_dept_click()" id="spices_dept">Spices</a></li>            
                            <li><a href="javascript:drinks_dept_click()" id="drinks_dept">Drinks</a></li>
                            <li><a href="javascript:none_dept_click()" id="none_dept">None</a></li>
                        </ul>

                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="php/search_products.php" method="POST">
                                <div class="hero__search__categories">
                                    All Categories
                                </div>
                                <input type="text" name="search_product" placeholder="What do yo u need?">
                                <button type="submit" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        
                    </div>
                    <div class="hero__item set-bg" data-setbg="img/hero/banner.jpg">
                        <div class="hero__text">
                            <span>FRUIT FRESH</span>
                            <h2>Vegetable <br />100% Organic</h2>
                            <br>
                            <!-- <p>Free Pickup and Delivery Available</p> -->
                            <a href="#" class="primary-btn">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Categories Section Begin -->
    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-1.jpg">
                            <h5><a>Fresh Fruit</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-2.jpg">
                            <h5><a href="#">Dried Fruit</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-3.jpg">
                            <h5><a href="#">Vegetables</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-4.jpg">
                            <h5><a href="#">Drink fruits</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-2.jpg">
                            <h5><a href="#">Dried fruits</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Categories Section End -->

    <!-- Featured Section Begin -->
    <section class="featured spad">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Featured Product</h2>
                    </div>   
                </div>
            </div>


    <!-- Product Section Begin -->

    <section class="products">
          <div class="product-card">
            <div class="product-image">
                <div class="container"  style="text-align: center;">
                    <?php
                    echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['product_image'] ).'" class = "db_image"/>';

                    ?>
                  <div class="middle">
                    <div class="text"><?php print("<h5>". $row["Fname"]." ". $row["Lname"]. "</h5>"); ?></div>
                  </div>
                </div>      
            </div>
            
            <div class="product-info" style="text-align: center;">
                <form action="php/adding_to_cart.php" method="POST">
                    <br>
                    <input type="hidden" name="product_id" value="<?=$row['upload_id']?>">
                    <input type="number" id='update_input' min= 1 max= 5 onkeydown='return false' name='update_product_quantity' value=1>
                    <button style=" width: 100px">Add to Cart</button>
                </form>
                <br>
                <?php print("<h5><b>Product Name : </b>". $row["product_name"]."</h5>"); ?>
              <?php print("<h6><b>Price ( per kg ) : </b>". $row["price"]."</h6>"); ?>
              <br>
            </div>
          </div>
        
    <?php
   
        if ($res->num_rows >= 0) {
            while($row = $res->fetch_assoc()) {
                
        ?> 
      <div class="product-card" style="text-align: center;">
        <div class="product-image">
            <div class="container">
                <?php
                echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['product_image'] ).'" class = "db_image" />';

                ?>
              <div class="middle">
                <div class="text"><?php print("<h5>". $row["Fname"]." ". $row["Lname"]. "</h5>"); ?></div>
              </div>
            </div>      
        </div>
        <div class="product-info" style="text-align: center;">
            <form action="php/adding_to_cart.php" method="POST">
                <br>
                <input type="hidden" name="product_id" value="<?=$row['upload_id']?>">
                <input type="number" id='update_input' min= 1 max= 5 onkeydown='return false' name='update_product_quantity' value=1>                
                <button>Add to Cart</button>
            </form>
            <br>
          <?php print("<h5><b>Product Name : </b>". $row["product_name"]."</h5>"); ?>
          <?php print("<h6><b>Price ( per kg ) : </b>". $row["price"]."</h6>"); ?>
          <br>
        </div>
      </div>
     <?php    
            }
                                                        
        } else {
            print("Updating soon...");
        } 
     ?>

    
  <!-- more products -->

     </section>
     <form action="php/shop-grid-test.php" method="POST">
        <center><button class="button" style="vertical-align:middle"><span>Explore &nbsp;</span>
        <span style="content: '\2192';"> &#8594;</span></button></center>
    </form>
    </section>

    <!-- Featured Section End -->

    <!-- Banner Begin -->
    <div class="banner">
        <div class="container mb-3">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="img/banner/banner-1.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="img/banner/banner-2.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->

    
    <!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6 mx-auto ">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="./index.php"><img src="img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: </li>
                            <li>Phone: </li>
                            <li>Email: </li>
                            
                        </ul>
                         <div class="footer__widget mt-3">
                        
                        <div class="footer__widget__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                    </div>
                    
                </div>
                
                
            </div>
            <div class="row">
                <div class="col-lg-6 mx-auto">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->
    	<?php
		if (isset($_SESSION['username'])) {
			
	?>
			<script type="text/javascript">
				document.getElementById('login_id_web').textContent = "<?php print($_SESSION['username']); ?>";
				document.getElementById('login_id_mobile').textContent = "<?php print($_SESSION['username']); ?>";
				document.getElementById('signout_id_web').textContent = "Sign-out";
				document.getElementById('signout_id_mobile').textContent = "Sign-out";
			
			</script>
	<?php
		}

	?>


    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
        function veg_dept_click() {
            
            document.cookie = "dept = Vegetables";
            location.replace("php/search_products.php");
        }
        function fruit_dept_click() {
            
            document.cookie = "dept = Fruits";
            location.replace("php/search_products.php");
        }
        function bne_dept_click() {
            
            document.cookie = "dept = Butter & Eggs";
            location.replace("php/search_products.php");
        }
        function spices_dept_click() {
            
            document.cookie = "dept = Spices";
            location.replace("php/search_products.php");
        }function drinks_dept_click() {
            
            document.cookie = "dept = Drinks";
            location.replace("php/search_products.php");
        }
        function none_dept_click() {
            
            document.cookie = "dept = None";
            location.replace("php/search_products.php");
        }
        function sessionclose()
        {
            window.open ("php/session_destroy.php","mywindow","status=1,toolbar=0"); 
            setTimeout(function (argument) {
                location.reload()
            },1700);
        }

        function login_check() {
         
            if (document.getElementById('login_id_web').textContent == "Login") {
                location.href = "html/login.html" ;
            }
            else
            {
                location.href = "php/viewprofile.php";
            }

            if (document.getElementById('login_id_mobile').textContent == "Login") {
                location.href = "html/login.html" ;
            }
            else
            {
                location.href = "php/viewprofile.php";
            }
        }

    </script>

</body>

</html>
