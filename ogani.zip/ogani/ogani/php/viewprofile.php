<?php
    session_start();
    // error_reporting(0);
    $conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');
    if ($conn) {
    	
    }
    $username = $_SESSION['username'];
    $checkout_fname = $_SESSION['fname'];
    $checkout_lname = $_SESSION['lname'];
    // print($checkout_lname);

    // print($_SESSION['username']);
    $user = $_SESSION['user_type'];
    if ($user == "Login As Customer") {
    	$sql = "SELECT * FROM customer_account WHERE username = '$username'";
    	$res = $conn->query($sql);
	    $row = $res->fetch_array(MYSQLI_ASSOC);
	    $count = $res->num_rows;

        $sql2 = "SELECT * FROM order_details WHERE (fname = '$checkout_fname' and lname = '$checkout_lname') and status = 'pending'";
        $res2 = $conn->query($sql2);
        // $row2 = $res2->fetch_array(MYSQLI_ASSOC);
        // $count2 = $res2->num_rows;

        $sql3 = "SELECT * FROM order_details WHERE (fname = '$checkout_fname' and lname = '$checkout_lname') and status = 'paid'";
        $res3 = $conn->query($sql3);
        // $row3 = $res3->fetch_array(MYSQLI_ASSOC);
        // $count3 = $res3->num_rows;

    	
    }
    elseif ($user == "Login As Farmer")
    {
    	$sql = "SELECT * FROM farmer_account WHERE username = '$username'";
    	$res = $conn->query($sql);
    	$row = $res->fetch_array(MYSQLI_ASSOC);
	    $count = $res->num_rows;

    	
    	$sql1 = "SELECT * FROM farmer_upload_products WHERE username = '$username'";
    	$res1 = $conn->query($sql1);
    	// $row1 = $res1->fetch_array(MYSQLI_ASSOC);
	    // $count1 = $res1->num_rows;

    }
    

?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ogani | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="../css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="../css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="../css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="../css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="../css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="../css/style.css" type="text/css">

</head>
<style type="text/css">
.containerr {
  position: relative;
  width: auto;
  margin: auto;
}

.image {
  display: block;
  width: 100%;
  height: auto;
}

#fname,#lname, #username
{
	cursor: not-allowed;
}

/* Pen-specific styles */



.left-half, .right-half {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

h1 {
  font-size: 1.75rem;
  margin: 0 0 0.75rem 0;
}

/* Pattern styles */
.containero {
  display: flex;
}

.left-half {
  background-color: #FFFFFF;
  flex: 2;
  padding: 1rem;
}

.right-half {
  background-color: #eef0eb;
  flex: 3;
  padding: 1rem;
  /*border-radius: 50px;*/
  height: auto;
}
</style>


<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="../img/logo.png" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
            </ul>
        </div>
        <div class="humberger__menu__widget">
            
            <div class="header__top__right__auth">
                <a href="javascript:login_check()">
                    <i class="fa fa-user"></i> <label id="login_id_mobile" style="cursor: pointer;">Login</label> 
                </a>
            </div>
    
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="header__top__right__auth">
                <a href="javascript:sessionclose()">
                    <label id="signout_id_mobile" style="cursor: pointer;"></label>
                </a>    
            </div>

        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="../index.php">Home</a></li>
                <li><a href="shop-grid-test.php">Shop</a></li>
                <li><a href="viewprofile.php">Pages</a>
                    <ul class="header__menu__dropdown">
                        <li><a href="./shop-details.html">Shop Details</a></li>
                        <li><a href="shopping_cart.php">Shoping Cart</a></li>
                        <li><a href="checkout.php">Check Out</a></li>
                        
                    </ul>
                </li>
                <li><a href="../contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-pinterest-p"></i></a>
        </div>
        
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-pinterest-p"></i></a>
                            </div>
         
                            <div class="header__top__right__auth">
                               <a href="javascript:login_check()"><i class="fa fa-user"></i> <label id="login_id_web" style="cursor: pointer;">Login</label></a>
                            </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <div class="header__top__right__auth">
                                <a href="javascript:sessionclose()">
                                    <label id="signout_id_web" style="cursor: pointer;"></label>
                                </a>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="../index.php"><img src="../img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                        <ul>
                            <li><a href="../index.php">Home</a></li>
                            <li class="active"><a href="shop-grid-test.php">Shop</a></li>
                            <li><a href="viewprofile.php">Pages</a>
                                <ul class="header__menu__dropdown">
                                    <li><a href="./shop-details.html">Shop Details</a></li>
                                    <li><a href="shopping_cart.php">Shoping Cart</a></li>
                                    <li><a href="checkout.php">Check Out</a></li>
                                    
                                </ul>
                            </li>
                            <li><a href="../contact.html">Contact</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero hero-normal">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All departments</span>
                        </div>
                        
                        <ul>
                            <li><a href="javascript:veg_dept_click()" id="veg_dept">Vegetables</a></li>
                            <li><a href="javascript:fruit_dept_click()" id="fruit_dept">Fruits</a></li>
                            <li><a href="javascript:bne_dept_click()" id="bne_dept">Butter & Eggs</a></li>
                            <li><a href="javascript:spices_dept_click()" id="spices_dept">Spices</a></li>            
                            <li><a href="javascript:drinks_dept_click()" id="drinks_dept">Drinks</a></li>
                            <li><a href="javascript:none_dept_click()" id="none_dept">None</a></li>
                        </ul>

                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="#">
                                <div class="hero__search__categories">
                                    All Categories
                                    <span class="arrow_carrot-down"></span>
                                </div>
                                <input type="text" placeholder="What do yo u need?">
                                <button type="submit" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="../img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Organi Shop</h2>
                        <div class="breadcrumb__option">
                            <a href="../index.php">Home</a>
                            <span>Shop</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->



<section class="containero">
  <div class="left-half">
       <div class="containerr">
			<div class="col-md-19 mx-auto">
  				<img src="../img/user.jpg" alt="Avatar" class="image">
			</div>
		</div>
  </div>
  <div class="right-half">
    <article>

    <section id="login">
    <div class="container">
      <div class="row">
        <div class="col-md-6 mx-auto">
          <br>
                  <form method="POST" action="profile_update.php">
                      <div class="form-group">
                      	    <div class="form-group">
                        		<label for="fname">First Name : </label>
                          		<input type="text" id="fname" placeholder="First Name" required="" name="fname" class="form-control" readonly="">
                        	</div>
                        	    
                        	<div class="form-group">
                        		<label for="lname">Lname : </label>
                          		<input type="text" id="lname" placeholder="Last Name" required="" name="lname" class="form-control" readonly="">
                        	</div>
                        	<div class="form-group">
                        		<label for="username">Username</label>
                          		<input type="text" id="username" placeholder="Username" required="" name="username" class="form-control" readonly="">
                        	</div>
                        
                        	<div class="form-group">
	                            <label for="password">Password</label>
    	                        <input type="password" id="password" required="" placeholder="Enter Password" name="password" class="form-control">
      	                    </div>
							
							<div class="form-group">
        	                  <label for="phone">Phone</label>
           		              <input type="tel" placeholder=" Phone" id="phone" required="" name="phone" class="form-control" pattern="^\d{10}$">
 	                        </div>

     	                    <div class="form-group">
         		                <label for="email">Email</label>
                	            <input type="email" placeholder="Email" id="email" required="" name="email" class="form-control">
                        	</div>

                             <div class="form-group">
                                <label for="Address">Address</label>
                                <input type="text" placeholder="Address" id="address" required="" name="address" class="form-control">
                            </div>
                        
                        <!-- <div class="form-group">
                          <label for="email">Username</label>
                          <input type="text" placeholder="Enter Username" required="" name="username" class="form-control">
                        </div>                      --> 
                        
                            <div class="row">

                                <div class="col-md-12">
                                    <input type="submit" value="Update Details" name="user_button" class="btn btn-primary btn-block">
                                </div>
                            </div>                  
                      	</div>
                    </form>
                </div>
        	 </div>      
    	</div>
  </section>
    </article>



  </div>
</section>
<?php
if ($user == "Login As Farmer") {
?>
  <hr style="margin: 40px;">
  <div class="container">
    <div style="margin: auto; float: left;">
  <h2>Products Uploaded</h2>
  </div>
    <div class="row" style="margin: auto; float: right;">

        <div>
            <form method="POST" action="../upload_products.php">
                <input type="submit" value="Upload Products" name="user_button" class="btn btn-primary btn-block">
            </form>
        </div>
    </div>                  
    <br><br><br>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Product ID</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Qty</th>
        <th>Product Category</th>
      </tr>
    </thead>
    <tbody>
<?php
 
    while($row1 = mysqli_fetch_array($res1))
    {
    echo "<tr>";
    echo "<td>" . $row1['upload_id'] . "</td>";
    echo "<td>" . $row1['product_name'] . "</td>";
    echo "<td>" . $row1['price'] . "</td>";
    echo "<td>" . $row1['product_qty'] . "</td>";
    echo "<td>" . $row1['product_category'] . "</td>";
    echo "</tr>";
    }
}
if ($user == "Login As Customer") 
{
?>
    <br><br><br>
  <div class="container">
                  
  <table class="table table-hover">
    <thead>
    <tr>
        <th colspan="6" style="text-align: center;">Active Order</th>
    </tr>
      <tr>
        <th>Product ID</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Qty</th>
        <th>Product Total Price</th>
        <th>Purchase Date</th>
      </tr>
    </thead>
    <tbody>
<?php
 
    while($row2 = mysqli_fetch_array($res2))
    {
    echo "<tr>";
    echo "<td>" . $row2['product_id'] . "</td>";
    echo "<td>" . $row2['items'] . "</td>";
    echo "<td>" . $row2['item_price'] . "</td>";
    echo "<td>" . $row2['item_quantity'] . "</td>";
    echo "<td>" . $row2['item_total_price'] . "</td>";
    echo "<td>" . $row2['date'] . "</td>";
    echo "</tr>";
    }
}

if ($user == "Login As Customer") {
    echo "<br>";


?>

  <div class="container">
  <table class="table table-hover">
    <br><br>
    <thead>
      <tr style="margin-top: 1000px;">
        <th colspan="7" style="text-align: center;">Past Order</th>
      </tr>
      <tr>
        <th>Product ID</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Qty</th>
        <th>Product Total Price</th>
        <th>Purchase Date</th>
        <th>Payment Date</th>
      </tr>
    </thead>
    <tbody>
<?php
 
    while($row3 = mysqli_fetch_array($res3))
    {
    echo "<tr>";
    echo "<td>" . $row3['product_id'] . "</td>";
    echo "<td>" . $row3['items'] . "</td>";
    echo "<td>" . $row3['item_price'] . "</td>";
    echo "<td>" . $row3['item_quantity'] . "</td>";
    echo "<td>" . $row3['item_total_price'] . "</td>";
    echo "<td>" . $row3['date'] . "</td>";
    echo "<td>" . $row3['payment_date'] . "</td>";
    echo "</tr>";
    }
}
?>

    </tbody>
  </table>
</div>





    <!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer__about">
                      
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="../index.php"><img src="../img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: -</li>
                            <li>Phone: -</li>
                            <li>Email: -</li>
                        </ul><br>
                        <div class="footer__widget">
                            
                            <div class="footer__widget__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>
            <div class="row"><div class="col-lg-3">
            </div>
                <div class="col-lg-9">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <?php
    if (isset($_SESSION['username'])) {
        
?>
        <script type="text/javascript">
            document.getElementById('login_id_web').textContent = "<?php print($_SESSION['username']); ?>";
            document.getElementById('login_id_mobile').textContent = "<?php print($_SESSION['username']); ?>";
            document.getElementById('signout_id_web').textContent = "Sign-out";
            document.getElementById('signout_id_mobile').textContent = "Sign-out";

        
        </script>
<?php
    }

?>

    <!-- Js Plugins -->
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jquery.slicknav.js"></script>
    <script src="../js/mixitup.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/main.js"></script>
    <script type="text/javascript">
        function veg_dept_click() {
            
            document.cookie = "dept = Vegetables";
            location.replace("search_products.php");
        }
        function fruit_dept_click() {
            
            document.cookie = "dept = Fruits";
            location.replace("search_products.php");
        }
        function bne_dept_click() {
            
            document.cookie = "dept = Butter & Eggs";
            location.replace("search_products.php");
        }
        function spices_dept_click() {
            
            document.cookie = "dept = Spices";
            location.replace("search_products.php");
        }function drinks_dept_click() {
            
            document.cookie = "dept = Drinks";
            location.replace("search_products.php");
        }
        function none_dept_click() {
            
            document.cookie = "dept = None";
            location.replace("search_products.php");
        }
        function sessionclose()
        {
            window.open ("session_destroy.php","mywindow","status=1,toolbar=0"); 
            setTimeout(function (argument) {
                location.replace("../index.php");
            },1700);
        }

        function login_check() {
         
            if (document.getElementById('login_id_web').textContent == "Login") {
                location.href = "../html/login.html" ;
            }
            else
            {
                location.href = "viewprofile.php";
            }

            if (document.getElementById('login_id_mobile').textContent == "Login") {
                location.href = "../html/login.html" ;
            }
            else
            {
                location.href = "viewprofile.php";
            }
        }
        <?php if ($user == "Login As Customer") { ?>
        document.getElementById('fname').value = "<?php print($row['fname']); ?>";
        document.getElementById('lname').value = "<?php print($row['lname']); ?>";
        document.getElementById('username').value = "<?php print($row['username']); ?>";
        document.getElementById('password').value = "<?php print($row['password']); ?>";
        document.getElementById('phone').value = "<?php print($row['phone']); ?>";
        document.getElementById('email').value = "<?php print($row['email']); ?>";
        document.getElementById('address').value = "<?php print($row['address']); ?>";
        <?php } ?>

        <?php if ($user == "Login As Farmer") { ?>
        document.getElementById('fname').value = "<?php print($row['Fname']); ?>";
        document.getElementById('lname').value = "<?php print($row['Lname']); ?>";
        document.getElementById('username').value = "<?php print($row['username']); ?>";
        document.getElementById('password').value = "<?php print($row['password']); ?>";
        document.getElementById('phone').value = "<?php print($row['phone']); ?>";
        document.getElementById('email').value = "<?php print($row['email']); ?>";
        document.getElementById('address').value = "<?php print($row['address']); ?>";
        <?php } ?>

    </script>


</body>

</html>