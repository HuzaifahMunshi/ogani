<?php
	session_start();
 	$conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');

 	$cname = $_POST['name_of_user'];
 	$order_id = $_POST['order_id'];
 	$name = explode(" ", $cname);
 	 // print_r($name);

 	 $fname = $name[0];
 	 $lname = $name[1];
// 	print($_SESSION['order_id']);
 	$cart_item = array();
	$cart_price = array();
	$item_quantity = array();
	$item_total_price = array();
	$product_id = array();
    $farmer_name = array();
    $farmer_quantity = array();

  //  $lname = sizeof($name);
  //  print($name$lname);
	$sql = "SELECT * FROM order_details WHERE status = 'pending' and fname = '$fname' and lname =  '$lname'  and order_id = '$order_id' order by date asc";
	// print($sql);
 	$res = $conn->query($sql);
 	$row = $res->fetch_array(MYSQLI_ASSOC);
	$count = $res->num_rows;

	// print($count);
	$cart_item = $row['items'];
	$cart_price = $row['item_price'];
	$item_quantity = $row['item_quantity'];
	$item_total_price = $row['item_total_price'];
	$product_id = $row['product_id'];
    $farmer_name = $row['farmers'];

	// print_r($cart_item);
	// print_r($cart_price);
	// print_r($item_quantity);
	// print_r($item_total_price);
	// print_r($product_id);
	// print_r($farmer_name);

	$cart_item = explode(',', $cart_item);
	$cart_price = explode(',', $cart_price);
	$item_quantity = explode(',', $item_quantity);
	$item_total_price = explode(',', $item_total_price);
	$product_id = explode(',', $product_id);
	$farmer_name = explode(',', $farmer_name);


	// print("<br>");
	// print_r($cart_item);
	// print("<br>");
	// print_r($cart_price);
	// print("<br>");
	// print_r($item_quantity);
	// print("<br>");
	// print_r($item_total_price);
	// print("<br>");
	// print_r($product_id);
	// print("<br>");
	// print_r($farmer_name);
	// print("<br>");
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Products to Deliver</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style type="text/css">
	table, th,tr,td
	{
		/*align-content: center;*/
		text-align: center;

	}


</style>


</head>


<body>
	<br><br><br>
	<table class="table table-hover">
	    <thead>
	    	<h1 align="center">Order ID : <?php print($row['order_id'])?></h1>
	    	<br>
	    <tr>
	        <th colspan="6" style="text-align: center;">Products ordered by <?php print($name[0]. " ". $name[1]) ?></th>
	    </tr>
	      <tr>
	        <th>Product ID</th>
	        <th>Name</th>
	        <th>Price</th>
	        <th>Quantity</th>
	        <th>Total Price</th>
	        <th>Farmer's Name</th>

	        <!-- <th>Phone</th>
	        <th>E - Mail</th>
	        <th>Purchase Date</th>
	        <th>View Products</th> -->
	       </tr>
	    </thead>
	    <tbody>

	<?php

 	if($res)
 	{

		    for ($i=0; $i <count($cart_item) ; $i++) 
 		{ 
 			echo "<tr>";
		    echo "<td>" . $product_id[$i] . "</td>";
		    echo "<td>" . $cart_item[$i] . "</td>";
		    echo "<td>" . $cart_price[$i] . "</td>";
		    echo "<td>" . $item_quantity[$i] . "</td>";
		    echo "<td>" . $item_total_price[$i] . "</td>";
		    echo "<td>" . $farmer_name[$i] . "</td>";
		    // echo "<td>" . $product_id[$i] . "</td>";
		    // echo "<td>" . $product_id[$i] . "</td>";
		    // echo "<td>" . $product_id[$i] . "</td>";
		    
 		}

 	}
 	else
 	{
 		print(mysqli_error($conn));
 	}
 ?>

	    <tr style="font-size: 20px">
	        <th>Total Price</th>
	        <th></th>
	        <th></th>
	        <th></th>

	    <th>
	    	<?php
	    	print("&#8377; ". $row['total']);
	    	?>
	    </th>
	    <th></th>
	    </tr>



</tbody>
</table>


<table class="table table-hover" align="center">
	    <thead>
	</thead>
</table>


<!-- 
<form> -->
	<center>
	<button onclick="javascript:update_paid()">Mark As Paid</button>
	</center>
<!-- </form> -->

<script type="text/javascript">
	function update_paid() 
	{
		<?php $_SESSION['order_id'] = $order_id; ?>
		var order = "<?php print($_SESSION['order_id']); ?>"
		// var order = "<?php print($order_id); ?>"
		// alert(order);
		window.open ("update_paid.php","mywindow","status=1,toolbar=0"); 
        setTimeout(function (argument) {
            location.href = "product_delivery.php"
        },1700);
	}


</script>



</body>
</html>