<!DOCTYPE html>
<html>
<head>
    <!-- <meta http-equiv="refresh" content="1.5; url=../index.php" /> -->

	<title>Signing out...</title>
</head>
<body>

	<p>Please wait!!  Signing out...</p>

<?php
		session_start();
		session_destroy();
?>


<script type="text/javascript">
	setTimeout(function(argument) {
		// body...
	window.close();
	},1500);
</script>
</body>
</html>
