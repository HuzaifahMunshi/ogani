<?php
	error_reporting(0);
	$AUTH_USER = 'admin';
	$AUTH_PASS = 'admin';
	header('Cache-Control: no-cache, must-revalidate, max-age=0');
	$has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	$is_not_authenticated = (
		!$has_supplied_credentials ||
		$_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
		$_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
	);
	if ($is_not_authenticated) {
		print("Access denied");	
		header('HTTP/1.1 401 Authorization Required');
		header('WWW-Authenticate: Basic realm="Access denied"');
		exit;
	}
	    $conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="7;" />

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      position: relative;
      /*height: 10%;*/
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }

  </style>
</head>
<script type="text/javascript">

	function myfunction(argument) {
	var farm = document.getElementById("farmer_div");	
	var cust  = document.getElementById('customer_div');

		farm.style.display = "none";
		cust.style.display = "block";
	}

	function myfunction2(argument) {
	var farm = document.getElementById("farmer_div");
	var cust  = document.getElementById('customer_div');
		
		cust.style.display = "none";
		farm.style.display = "block";
	
	}

</script>
<body>

	<center>
	<br><br>
	<strong><i>Update Page for new orders</i></strong>
	<br>
	 <button style="font-size: 20px; padding: 5px;" id="customer" onclick="javascript:myfunction()">View Customer Data</button>
	<!-- <br><br> -->&nbsp;&nbsp;&nbsp;&nbsp;
	 <button style="font-size: 20px; padding: 5px;" id="farmer" onclick="javascript:myfunction2()">View Farmer Data</button>
    </center>

    <div class="col-sm-12 text-left">
	    <div id="customer_div" style="display: block;"> 
	      <h1 align="center">Customer Data</h1>

	      <?php
 			
 			$sql = "SELECT * FROM order_details WHERE status = 'pending' order by date asc";
 			$res = $conn->query($sql);
 		  ?>
			 <table class="table table-hover">
			    <thead>
			    <tr>
			        <th colspan="6" style="text-align: center;">Active Order</th>
			    </tr>
			      <tr>
			        <th>First Name</th>
			        <th>Last Name</th>
			        <th>Address</th>
			        <th>City</th>
			        <th>State</th>
			        <th>Pincode</th>
			        <th>Phone</th>
			        <th>E - Mail</th>
			        <th>Purchase Date</th>
			        <th>View Products</th>
			       </tr>
			    </thead>
			    <tbody>
		  
		    
		  <?php
		    while($row = mysqli_fetch_array($res))
		    {

		    echo "<tr>";
		    echo "<td>" . $row['fname'] . "</td>";
		    echo "<td>" . $row['lname'] . "</td>";
		    echo "<td>" . $row['address'] . "</td>";
		    echo "<td>" . $row['city'] . "</td>";
		    echo "<td>" . $row['state'] . "</td>";
		    echo "<td>" . $row['pincode'] . "</td>";
		    echo "<td>" . $row['phone'] . "</td>";
		    echo "<td>" . $row['email'] . "</td>";
		    echo "<td>" . $row['date'] . "</td>";
?>
		  	<?php
		    echo "<td>
		    	  <form method='POST' action='order_profile.php'>";
		    echo "<input type='hidden' name='name_of_user' value ='".$row['fname']. "".  $row['lname'] . "'>
		    	  <input type='hidden' name='order_id' value ='".$row['order_id'] . "'>	
		    	  <button> Click Here</button></form>
		    	  </td>";
		    echo "</tr>";
		    }

		?>
		

		
			</table>
	    </div>

	


	     <div id="farmer_div" style="display: none;"> 
	      <h1 align="center">Farmer Data</h1>

			 <table class="table table-hover">
			    <thead>
			    <tr>
			        <th colspan="6" style="text-align: center;">Farmer Data</th>
			    </tr>
			      <tr>
			        <th>First Name</th>
			        <th>Last Name</th>
			        <th>Phone</th>
			        <th>E - Mail</th>
			        <th>Address</th>
			        <th>View Products</th>
			       </tr>
			    </thead>
			    <tbody>
		  
		    
		  <?php

			$sql = "SELECT * FROM farmer_account";
			$result = mysqli_query($conn, $sql); 
			echo "<br>";
			while ($row = mysqli_fetch_assoc($result)) 
			{ 
		    echo "<tr>";
		    echo "<td>" . $row['Fname'] . "</td>";
		    echo "<td>" . $row['Lname'] . "</td>";
		    echo "<td>" . $row['phone'] . "</td>";
		    echo "<td>" . $row['email'] . "</td>";
		    echo "<td>" . $row['address'] . "</td>";
?>
		  	<?php
		    echo "<td>
		    	  <form method='POST' action='farmer_profile.php'>";
		    echo "<input type='hidden' name='name_of_farmer' value ='".$row['Fname']. " ".  $row['Lname'] . "'>	
		    	  <button> Click Here</button></form>
		    	  </td>";
		    echo "</tr>";
		    }

		?>

		
			</table>
	    </div>	
</body>
</html>
