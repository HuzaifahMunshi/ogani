<?php
    session_start();
    // error_reporting(0);
    $conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');
    if ($conn) {
		// print("Connected");    	
    }

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $button = $_SESSION['user_type'];
    // print($button);
	
?>  



<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ogani | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="../css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="../css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="../css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="../css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="../css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="../css/style.css" type="text/css">


    <style>

.products {
  	display: flex;
	flex-wrap: wrap;
	justify-content: center;
}

.product-card{
	padding: 1%;
	margin-left: 10px;
}
.product-image img {
  max-width: 100%;


}
.product-info {
  margin-top: auto;
}
@media (max-width: 920px) {
  .product-card {
    flex: 1 21%;
  }
}
@media (max-width: 600px) {
  .product-card {
    flex: 1 46%;
  }
}

@media (max-width: 480px) {
  .product-filter {
    flex-direction: column;
  }
  .sort {
    align-self: flex-start;
  }
}
.container {
  position: relative;
  width: 100%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.3;
}

.container:hover .middle {
  opacity: 1;
}

.text {
  background-color: #7fad39;
  border-radius: 30px;
  color: white;
  font-size: 10px;
  padding: 16px 32px;
}

.db_image
{
    background-color: #f3f6fb;
    width: 270px;
    height: 270px;
    background-position: center;
    /*background-size: stretch;*/

}

</style>

</head>





<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="../img/logo.png" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
            </ul>
        </div>
        <div class="humberger__menu__widget">
            
            <div class="header__top__right__auth">
                <a href="javascript:login_check()">
                    <i class="fa fa-user"></i> <label id="login_id_mobile" style="cursor: pointer;">Login</label> 
                </a>
            </div>
    
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="header__top__right__auth">
                <a href="javascript:sessionclose()">
                    <label id="signout_id_mobile" style="cursor: pointer;"></label>
                </a>    
            </div>

        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="../index.php">Home</a></li>
                <li><a href="shop-grid-test.php">Shop</a></li>
                <li><a href="profile_update.php">Pages</a>
                    <ul class="header__menu__dropdown">
                        <li><a href="shop-grid-test.php">Shop Details</a></li>
                        <li><a href="shopping_cart.php">Shoping Cart</a></li>
                        <li><a href="../checkout.html">Check Out</a></li>
                    </ul>
                </li>
                <li><a href="../contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-pinterest-p"></i></a>
        </div>
        
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-pinterest-p"></i></a>
                            </div>
         
                            <div class="header__top__right__auth">
                               <a href="javascript:login_check()"><i class="fa fa-user"></i> <label id="login_id_web" style="cursor: pointer;">Login</label></a>
                            </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <div class="header__top__right__auth">
                                <a href="javascript:sessionclose()">
                                    <label id="signout_id_web" style="cursor: pointer;"></label>
                                </a>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="../index.php"><img src="../img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                        <ul>
                            <li><a href="../index.php">Home</a></li>
                            <li class="active"><a href="shop-grid-test.php">Shop</a></li>
                            <li><a href="profile_update.php">Pages</a>
                                <ul class="header__menu__dropdown">
                                    <li><a href="shop-grid-test.php">Shop Details</a></li>
                                    <li><a href="shopping_cart.php">Shoping Cart</a></li>
                                    <li><a href="../checkout.html">Check Out</a></li>
                                </ul>
                            </li>
                            <li><a href="../contact.html">Contact</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-2">
                    
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero hero-normal">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All departments</span>
                        </div>
                        
                        <ul>
                            <li><a href="javascript:veg_dept_click()" id="veg_dept">Vegetables</a></li>
                            <li><a href="javascript:fruit_dept_click()" id="fruit_dept">Fruits</a></li>
                            <li><a href="javascript:bne_dept_click()" id="bne_dept">Butter & Eggs</a></li>
                            <li><a href="javascript:spices_dept_click()" id="spices_dept">Spices</a></li>            
                            <li><a href="javascript:drinks_dept_click()" id="drinks_dept">Drinks</a></li>
                            <li><a href="javascript:none_dept_click()" id="none_dept">None</a></li>
                        </ul>

                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="#">
                                <div class="hero__search__categories">
                                    All Categories
                                    <span class="arrow_carrot-down"></span>
                                </div>
                                <input type="text" placeholder="What do yo u need?">
                                <button type="submit" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="../img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Organi Shop</h2>
                        <div class="breadcrumb__option">
                            <a href="../index.php">Home</a>
                            <span>Shop</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

<?php

	if ($button == "Login As Farmer") 
	{
		$sql = "UPDATE farmer_account SET password = '$password', phone = '$phone', email = '$email', address = '$address' WHERE username = '$username'";
		// $res = $conn->query($sql);
		if ($res = $conn->query($sql)) 
		{
		?>
				<br><br>
				<div class="alert alert-success">
				    <strong>Success!!!</strong>   Update Successfull!!!
				</div>
				<h4 align="center">Please wait...</h4>

				<script type="text/javascript">
					setTimeout("location.href = 'viewprofile.php';", 1500);
				</script>


			<?php
		}
		else
		{
		?>
			<br><br>
			<div class="alert alert-warning">
			    <strong>Warning!!!</strong>   Account Exists!!!
			</div>
			<h4 align="center">Please wait...</h4>

			<script type="text/javascript">
				setTimeout("location.href = 'viewprofile.php';", 1500);
			</script>


			<?php
		}
	}
	if ($button == "Login As Customer")
	{
		$sql = "UPDATE customer_account SET password = '$password', phone = '$phone', email = '$email', address = '$address' WHERE username = '$username'";
		$res = $conn->query($sql);
		if ($res) 
		{
		?>
				<br><br>
				<div class="alert alert-success">
				    <strong>Success!!!</strong>   Update Successfull!!!
				</div>
				<h4 align="center">Please wait...</h4>

				<script type="text/javascript">
					setTimeout("location.href = 'viewprofile.php';", 1500);
				</script>


			<?php
		}
		else
		{
		?>
			<br><br>
			<div class="alert alert-warning">
			    <strong>Warning!!!</strong>   Account exists!!!
			</div>
			<h4 align="center">Please wait...</h4>

			<script type="text/javascript">
				setTimeout("location.href = 'viewprofile.php';", 1500);
			</script>


			<?php

		}
	}	
	
?>



    <!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer__about">
                      
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="../index.php"><img src="../img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: -</li>
                            <li>Phone: -</li>
                            <li>Email: -</li>
                        </ul><br>
                        <div class="footer__widget">
                            
                            <div class="footer__widget__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>
            <div class="row"><div class="col-lg-3">
            </div>
                <div class="col-lg-9">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <?php
    if (isset($_SESSION['username'])) {
        
?>
        <script type="text/javascript">
            document.getElementById('login_id_web').textContent = "<?php print($_SESSION['username']); ?>";
            document.getElementById('login_id_mobile').textContent = "<?php print($_SESSION['username']); ?>";
            document.getElementById('signout_id_web').textContent = "Sign-out";
            document.getElementById('signout_id_mobile').textContent = "Sign-out";
        
        </script>
<?php
    }

?>

    <!-- Js Plugins -->
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jquery.slicknav.js"></script>
    <script src="../js/mixitup.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/main.js"></script>
    <script type="text/javascript">
        function veg_dept_click() {
            
            document.cookie = "dept = Vegetables";
            location.replace("search_products.php");
        }
        function fruit_dept_click() {
            
            document.cookie = "dept = Fruits";
            location.replace("search_products.php");
        }
        function bne_dept_click() {
            
            document.cookie = "dept = Butter & Eggs";
            location.replace("search_products.php");
        }
        function spices_dept_click() {
            
            document.cookie = "dept = Spices";
            location.replace("search_products.php");
        }function drinks_dept_click() {
            
            document.cookie = "dept = Drinks";
            location.replace("search_products.php");
        }
        function none_dept_click() {
            
            document.cookie = "dept = None";
            location.replace("search_products.php");
        }
        function sessionclose()
        {
            window.open ("session_destroy.php","mywindow","status=1,toolbar=0"); 
            setTimeout(function (argument) {
                location.reload()
            },1700);
        }

        function login_check() {
         
            if (document.getElementById('login_id_web').textContent == "Login") {
                location.href = "../html/login.html" ;
            }
            else
            {
                location.href = "viewprofile.php";
            }

            if (document.getElementById('login_id_mobile').textContent == "Login") {
                location.href = "../html/login.html" ;
            }
            else
            {
                location.href = "viewprofile.php";
            }
        }
    </script>


</body>

</html>