<?php
    error_reporting(0);
	session_start();
	$conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');

    $username = $_SESSION['username'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $country = $_POST['country'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $order_notes = $_POST['order_notes'];
    $subtotal = $_SESSION['subtotal'];
    $chkbox = $_POST['cod'];


    // $sql = "SELECT * FROM order_details
    // 		WHERE username = '$username'";
    // $res = $conn->query($sql);
    // $row = $res->fetch_array(MYSQLI_ASSOC);
    // $count = $res->num_rows;

    // print($fname."<br>");
    // print($lname."<br>");
    // print($country."<br>");
    // print($address."<br>");
    // print($city."<br>");
    // print($state."<br>");
    // print($postcode."<br>");
    // print($phone."<br>");
    // print($email."<br>");
    // print($order_notes."<br>");
    // print($row['cart_item']."<br>");
    // print($row['cart_price']."<br>");
    // print($row['item_quantity']."<br>");
    // print($row['item_total_price']."<br>");
    // while($row = mysqli_fetch_assoc($res))
    // {
    // 	print($row['cart_item']."<br>");
    // print($row['cart_price']."<br>");
    // print($row['item_quantity']."<br>");
    // print($row['item_total_price']."<br>");
    // }    
    // print($subtotal."<br>");
    // print($chkbox);
    

?>


<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ogani | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="../css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="../css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="../css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="../css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="../css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="../css/style.css" type="text/css">

    </head>



<body>
    <!-- Page Preloder -->
 <!--    <div id="preloder">
        <div class="loader"></div>
    </div>
 -->
    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="../img/logo.png" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
            </ul>
        </div>
        <div class="humberger__menu__widget">
            
            <div class="header__top__right__auth">
                <a href="javascript:login_check()">
                    <i class="fa fa-user"></i> <label id="login_id_mobile" style="cursor: pointer;">Login</label> 
                </a>
            </div>
    
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="header__top__right__auth">
                <a href="javascript:sessionclose()">
                    <label id="signout_id_mobile" style="cursor: pointer;"></label>
                </a>    
            </div>

        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="../index.php">Home</a></li>
                <li><a href="shop-grid-test.php">Shop</a></li>
                <li><a href="checkout_update.php">Pages</a>
                    <ul class="header__menu__dropdown">
                        <li><a href="./shop-details.html">Shop Details</a></li>
                        <li><a href="shoping_cart.php">Shoping Cart</a></li>
                        <li><a href="./checkout.php">Check Out</a></li>
                        <li><a href="../farmer_upload_products.php">Upload Products</a></li>
                    </ul>
                </li>
                <li><a href="../contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-pinterest-p"></i></a>
        </div>
        
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-pinterest-p"></i></a>
                            </div>
         
                            <div class="header__top__right__auth">
                               <a href="javascript:login_check()"><i class="fa fa-user"></i> <label id="login_id_web" style="cursor: pointer;">Login</label></a>
                            </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <div class="header__top__right__auth">
                                <a href="javascript:sessionclose()">
                                    <label id="signout_id_web" style="cursor: pointer;"></label>
                                </a>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="../index.php"><img src="../img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                        <ul>
                            <li><a href="../index.php">Home</a></li>
                            <li class="active"><a href="shop-grid-test.php">Shop</a></li>
                            <li><a href="checkout_update.php">Pages</a>
                                <ul class="header__menu__dropdown">
                                    <li><a href="./shop-details.html">Shop Details</a></li>
                                    <li><a href="shoping_cart.php">Shoping Cart</a></li>
                                    <li><a href="./checkout.php">Check Out</a></li>
                                    <li><a href="../farmer_upload_products.php">Upload Products</a></li>
                                </ul>
                            </li>
                            <li><a href="../contact.html">Contact</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-2">
                    <div class="header__cart">
                        <ul>
                            <li><a href="#"><i class="fa fa-shopping-bag" style="font-size: 30px"></i> <span>3</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero hero-normal">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All departments</span>
                        </div>
                        
                        <ul>
                            <li><a href="javascript:veg_dept_click()" id="veg_dept">Vegetables</a></li>
                            <li><a href="javascript:fruit_dept_click()" id="fruit_dept">Fruits</a></li>
                            <li><a href="javascript:bne_dept_click()" id="bne_dept">Butter & Eggs</a></li>
                            <li><a href="javascript:spices_dept_click()" id="spices_dept">Spices</a></li>            
                            <li><a href="javascript:drinks_dept_click()" id="drinks_dept">Drinks</a></li>
                            <li><a href="javascript:none_dept_click()" id="none_dept">None</a></li>
                        </ul>

                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="#">
                                <div class="hero__search__categories">
                                    All Categories
                                    <span class="arrow_carrot-down"></span>
                                </div>
                                <input type="text" placeholder="What do yo u need?">
                                <button type="submit" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="../img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Organi Shop</h2>
                        <div class="breadcrumb__option">
                            <a href="../index.php">Home</a>
                            <span>Shop</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->




	<?php

		$sql1 = "SELECT * FROM customer_order
				 WHERE username = '$username' and status = 'active'";
		$res1 = $conn->query($sql1);
		$row1 = $res1->fetch_array(MYSQLI_ASSOC);
		$count1 = $res1->num_rows;

        $status = 'pending';
		$cart_item = array();
		$cart_price = array();
		$item_quantity = array();
		$item_total_price = array();
		$product_id = array();
        $farmer_name = array();
        $farmer_quantity = array();

		$cart_item[0] = $row1['cart_item'];
		$cart_price[0] = $row1['cart_price'];
		$item_quantity[0] = $row1['item_quantity'];
		$item_total_price[0] = $row1['item_total_price'];
		$product_id[0] = $row1['product_id'];
        $farmer_name[0] = $row1['farmer_name'];


		$index = 1;
		while ($row1 = mysqli_fetch_assoc($res1)) 
		{
	    	$cart_item[$index] = $row1['cart_item'];
	    	$cart_price[$index] = $row1['cart_price'];
	    	$item_quantity[$index] = $row1['item_quantity'];
	    	$item_total_price[$index] = $row1['item_total_price']; 
	    	$product_id[$index] = $row1['product_id'];
            $farmer_name[$index] = $row1['farmer_name'];
	    	$index++;
		}
		// print_r($cart_item);
		// print("<br>");
	
		$items = implode(',', $cart_item);
		// print($items);
		// print("<br>");
		
		// print_r($cart_price);
		// print("<br>");
	
		$item_initial_price = implode(',', $cart_price);
		// print($item_initial_price);
		// print("<br>");

		// print_r($item_quantity);
		// print("<br>");
	
		$item_user_quantity = implode(',', $item_quantity);
		// print($item_user_quantity);
		// print("<br>");

		// print_r($item_total_price);
		// print("<br>");
	
		$order_item_total_price = implode(',', $item_total_price);
		// print($order_item_total_price);
		// print("<br>");

		$product_id_final = implode(',', $product_id);
		// print($order_item_total_price);
		// print("<br>");

		// print($subtotal);
        $farmers = implode(',', $farmer_name);

        date_default_timezone_set('Asia/Kolkata'); 

        $date_pur = date('Y-m-d H:i:s');
        $date_purchased = $date_pur;

		if (strcasecmp($country, 'India') == 0) 
		{
    		if($chkbox == 'cod')
    		{

    		}
    		elseif ($chkbox == 'paypal')
    		{

    		}
            $index1 = 0;
    		// print(is_string($item_initial_price));
    		$sql2 = "INSERT INTO order_details
    				(fname, lname, address, city, state, pincode, phone, email, order_notes, product_id, farmers, items, item_price, item_quantity, item_total_price, total, date, status)
    				VALUES
    				('$fname','$lname','$address','$city','$state','$pincode','$phone','$email','$order_notes', '$product_id_final', '$farmers', '$items','$item_initial_price','$item_user_quantity','$order_item_total_price','$subtotal', '$date_purchased', '$status')";

    		$res2 = $conn->query($sql2);
    		if ($res2) 
    		{
    			#product quantity decrease 
    			#decrease quantity according to farmers name
                for ($i=0; $i < count($cart_item); $i++) { 
                    // print($product_id[$i]);
                    // print("Goig in");
                    $sql6 = "INSERT INTO previous_customer_order 
                        (Fname, Lname, username, product_id, cart_item, cart_price, item_quantity, item_total_price, farmer_name, date)
                        VALUES
                        ('$fname', '$lname', '$username', '$product_id[$i]', '$cart_item[$i]', '$cart_price[$i]', '$item_quantity[$i]', '$item_total_price[$i]', '$farmer_name[$i]', '$date_purchased')";

                    $res6 = $conn -> query($sql6);
                    if ($res6) {
                            // print("wow");
                        }    
                    else
                    {
                        // print(mysqli_error($conn));
                    }
                }

                foreach ($product_id as $p) 
                {
        			$sql3 = "SELECT * FROM farmer_upload_products WHERE upload_id = '$p'";
        			$res3 = $conn->query($sql3);
                    $row3 = $res3->fetch_array(MYSQLI_ASSOC);
                    $count3 = $res3->num_rows;



                    $sql5 = "UPDATE customer_order SET status='inactive' where product_id='$p' and username = '$username'";
                    $res5 = $conn->query($sql5);

                    $sql7 = "DELETE FROM customer_order 
                            WHERE
                            username = '$username' and product_id = '$p' and status = 'inactive'";

                    $res7 = $conn -> query($sql7);
                    if ($res7) {
                        // print("All perfect");
                    }
                    else
                    {
                        // print(mysqli_error($conn));
                    }

                    // print($row3['product_qty']);
                     $farmer_quantity[$index1] = $row3['product_qty']; 
                     $index1++;
                 } 
                // print_r($farmer_quantity);
                // print("<br>");
                // print_r($item_quantity);
                // print("<br>");

                for ($i=0; $i < count($farmer_quantity) ; $i++) { 
                    $updated_quantity = $farmer_quantity[$i] - $item_quantity[$i];
                    $updated_product_id = $product_id[$i];
                    // print($updated_product_id);
                    // print($updated_quantity."<br>");
                    $sql4 = "UPDATE farmer_upload_products
                             SET product_qty = '$updated_quantity' 
                             WHERE upload_id = '$updated_product_id'";
                    $res4 = $conn->query($sql4);

                    
                    if($res4)
                    {
                        // print("Done");
                    }
                    else
                    {
                        // print("Error");
                    }
                }

			?>
				<br><br>
				<div class="alert alert-success">
				    <strong>Success!!!</strong>   Order has been placed
				</div>
				<h4 align="center">Thank you</h4>

				<script type="text/javascript">
	                // document.write("Success cust");
					setTimeout("location.href = '../index.php';", 2500);
				</script>
			<?php

    		}
    		else
    		{
                print(mysqli_error($conn));
			?>
				<br><br>
				<div class="alert alert-warning">
				    <strong>Warning!!!</strong>   Some error occurred
				</div>
				<h4 align="center">Retry Again</h4>

				<script type="text/javascript">
	                // document.write("Success cust");
					setTimeout("location.href = 'checkout.php';", 2500);
				</script>
			<?php

    		}

		}
		else
		{
		?>
			<br><br>
			<div class="alert alert-warning">
			    <strong>Warning!!!</strong>   Currently only indian users can shop!!!
			</div>
			<h4 align="center">Thank you</h4>

			<script type="text/javascript">
                // document.write("Success cust");
				setTimeout("location.href = 'checkout.php';", 2500);
			</script>
		<?php
		}



	?>









    <!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer__about">
                      
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="../index.php"><img src="../img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: -</li>
                            <li>Phone: -</li>
                            <li>Email: -</li>
                        </ul><br>
                        <div class="footer__widget">
                            
                            <div class="footer__widget__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>
            <div class="row"><div class="col-lg-3">
            </div>
                <div class="col-lg-9">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <?php
    if (isset($_SESSION['username'])) {
        
?>
        <script type="text/javascript">
            document.getElementById('login_id_web').textContent = "<?php print($_SESSION['username']); ?>";
            document.getElementById('login_id_mobile').textContent = "<?php print($_SESSION['username']); ?>";
            document.getElementById('signout_id_web').textContent = "Sign-out";
            document.getElementById('signout_id_mobile').textContent = "Sign-out";
        
        </script>
<?php
    }

?>

    <!-- Js Plugins -->
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jquery.slicknav.js"></script>
    <script src="../js/mixitup.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/main.js"></script>
    <script type="text/javascript">
        function veg_dept_click() {
            
            document.cookie = "dept = Vegetables";
            location.replace("search_products.php");
        }
        function fruit_dept_click() {
            
            document.cookie = "dept = Fruits";
            location.replace("search_products.php");
        }
        function bne_dept_click() {
            
            document.cookie = "dept = Butter & Eggs";
            location.replace("search_products.php");
        }
        function spices_dept_click() {
            
            document.cookie = "dept = Spices";
            location.replace("search_products.php");
        }function drinks_dept_click() {
            
            document.cookie = "dept = Drinks";
            location.replace("search_products.php");
        }
        function none_dept_click() {
            
            document.cookie = "dept = None";
            location.replace("search_products.php");
        }
        function sessionclose()
        {
            window.open ("session_destroy.php","mywindow","status=1,toolbar=0"); 
            setTimeout(function (argument) {
                location.reload()
            },1700);
        }

        function login_check() {
         
            if (document.getElementById('login_id_web').textContent == "Login") {
                location.href = "../html/login.html" ;
            }
            else
            {
                location.href = "viewprofile.php";
            }

            if (document.getElementById('login_id_mobile').textContent == "Login") {
                location.href = "../html/login.html" ;
            }
            else
            {
                location.href = "viewprofile.php";
            }            
        }

        // function updatecart() {

        //     document.write(updateqty);
        //      window.open ("updatequantity.php","mywindow","status=1,toolbar=0"); 
        //     // setTimeout(function (argument) {
        //         // location.reload()
        //     // },1700);
        // }
    </script>


</body>

</html>