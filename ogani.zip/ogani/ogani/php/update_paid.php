<?php
	session_start();
    $conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');
    if ($conn) {
    	
    }
    
    date_default_timezone_set('Asia/Kolkata'); 
    $date_paid = date('Y-m-d H:i:s');
    $order_id = $_SESSION['order_id'];
    // print($_SESSION['order_id']);

    $sql = "INSERT INTO product_payment 
            VALUES
            ('$order_id', '$date_paid')";

    $res = $conn->query($sql);

    $sql1 = "UPDATE order_details
            SET status = 'paid'
            WHERE order_id = '$order_id'";

    $res1 = $conn->query($sql1);

    if($res && $res1)
    {
    	print("Payment Done!!!");
    }
    else
    {
    	print("Error in payment");
    }

?>

<!DOCTYPE html>
<html>
<head>
	<title>Payment...</title>
	<script type="text/javascript">
		setTimeout(function(argument) {
			window.close();
		},1500);
	</script>
</head>
<body>
</body>
</html>