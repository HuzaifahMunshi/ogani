<?php
 	$conn = mysqli_connect('localhost', 'root', '', 'sd_ekjute');

 	$fname = $_POST['name_of_farmer'];
 	$name = explode(" ", $fname);
 	// print_r($name);


 	$cart_item = array();
	$cart_price = array();
	$item_quantity = array();
	$item_total_price = array();
	$product_id = array();
    $farmer_name = array();
    $farmer_quantity = array();


	$sql = "SELECT * FROM farmer_upload_products WHERE Fname =  '$name[0]' and Lname = '$name[1]' order by upload_id asc";
 	$res = $conn->query($sql);
 	$row = $res->fetch_array(MYSQLI_ASSOC);
	$count = $res->num_rows;

	// $cart_item = $row['items'];
	// $cart_price = $row['item_price'];
	// $item_quantity = $row['item_quantity'];
	// $item_total_price = $row['item_total_price'];
	// $product_id = $row['product_id'];
 //    $farmer_name = $row['farmers'];

	// // print_r($cart_item);
	// // print_r($cart_price);
	// // print_r($item_quantity);
	// // print_r($item_total_price);
	// // print_r($product_id);
	// // print_r($farmer_name);

	// $cart_item = explode(',', $cart_item);
	// $cart_price = explode(',', $cart_price);
	// $item_quantity = explode(',', $item_quantity);
	// $item_total_price = explode(',', $item_total_price);
	// $product_id = explode(',', $product_id);
	// $farmer_name = explode(',', $farmer_name);


	// print("<br>");
	// print_r($cart_item);
	// print("<br>");
	// print_r($cart_price);
	// print("<br>");
	// print_r($item_quantity);
	// print("<br>");
	// print_r($item_total_price);
	// print("<br>");
	// print_r($product_id);
	// print("<br>");
	// print_r($farmer_name);
	// print("<br>");
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Products to Deliver</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style type="text/css">
	table, th,tr,td
	{
		/*align-content: center;*/
		text-align: center;

	}


</style>


</head>


<body>
	<br><br><br>
	<table class="table table-hover">
	    <thead>
	    <tr>
	        <th colspan="6" style="text-align: center;">Products Uploaded by <?php print($name[0]. " ". $name[1]) ?></th>
	    </tr>
	      <tr>
	        <th>Product ID</th>
	        <th>Product Name</th>
	        <th>Product Price</th>
	        <th>Product Quantity</th>
	        <th>Product Category</th>
	        <!-- <th>Farmer's Name</th> -->

	        <!-- <th>Phone</th>
	        <th>E - Mail</th>
	        <th>Purchase Date</th>
	        <th>View Products</th> -->
	       </tr>
	    </thead>
	    <tbody>

	<?php

 	if($res)
 	{
			echo "<tr>";
		    echo "<td>" . $row['upload_id'] . "</td>";
		    echo "<td>" . $row['product_name'] . "</td>";
		    echo "<td>" . $row['price'] . "</td>";
		    echo "<td>" . $row['product_qty'] . "</td>";
		    echo "<td>" . $row['product_category'] . "</td>";
		    echo "</tr>";

 		while($row = mysqli_fetch_array($res)) 
 		{ 
 			echo "<tr>";
		    echo "<td>" . $row['upload_id'] . "</td>";
		    echo "<td>" . $row['product_name'] . "</td>";
		    echo "<td>" . $row['price'] . "</td>";
		    echo "<td>" . $row['product_qty'] . "</td>";
		    echo "<td>" . $row['product_category'] . "</td>";
		    // echo "<td>" . $farmer_name[$i] . "</td>";
		    // echo "<td>" . $product_id[$i] . "</td>";
		    // echo "<td>" . $product_id[$i] . "</td>";
		    // echo "<td>" . $product_id[$i] . "</td>";
		    
 		}

 	}
 	else
 	{
 		print(mysqli_error($conn));
 	}
 ?>

<!-- 	    <tr style="font-size: 20px">
	        <th>Total Price</th>
	        <th></th>
	        <th></th>
	        <th></th>

	    <th>
	    	<?php
	    	print("&#8377; ". $row['total']);
	    	?>
	    </th>
	    <th></th>
	    </tr>
 -->


</tbody>
</table>


<table class="table table-hover" align="center">
	    <thead>
	</thead>
</table>



<!-- <form>
	<center>
	<button>Mark As Paid</button>
	</center>
</form>
 -->
</body>
</html>